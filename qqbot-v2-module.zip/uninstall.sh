#!/system/bin/sh
# QQ机器人 v2 卸载：先停 v2 栈（尽力而为，失败也继续），再删 v2 自己
# 的环境与脚本目录。
# 只删 rootfs-v2 与 v2 —— 生产（rootfs、bin）、试验（rootfs-test、
# v4-test）、密钥暂存（secrets）都不碰；rootfs-v2.bak-* 是安装时的
# 半成品备份，归用户手动处理，这里也不删。
V2=/data/qqbot/v2
if [ -f "$V2/stop-all.sh" ]; then
  sh "$V2/stop-all.sh" >/dev/null 2>&1
fi
rm -rf /data/qqbot/rootfs-v2
rm -rf /data/qqbot/v2
