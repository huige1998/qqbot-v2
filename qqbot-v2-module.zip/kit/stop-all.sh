#!/system/bin/sh
# =====================================================================
# QQ机器人 v2 · 停止（同步执行，返回时保证停干净）
# 只停 v2 栈，三层下手:
#   1. 按 v2 的 pid 文件整组杀（watcher / bot / backend / napcat）；
#   2. 按 /proc/<pid>/root 指向 /data/qqbot/rootfs-v2 兜底清扫——生产
#      进程的 root 是 /data/qqbot/rootfs、试验是 rootfs-test，原理上
#      不可能误伤；
#   3. root 读不到（进程正在退出等瞬态）时才退到「令牌 + cwd」判定，
#      且只认后端两类令牌（设计 §2.2）：argv[0] 带 sh 的
#      /root/qqbot/start-backend.sh（后端看门狗本体）、argv[0] 带
#      python3 的 app.py（后端本体）。已知 root 属于别家时令牌再像
#      也不认——这是防误杀生产的硬线。
# 后端必须连看门狗一起收干净：只杀 app.py 的话看门狗 5 秒就把它
# 拉回来，8787 端口会被孤儿占着，下次起栈绑不上。
# 手动运行: sh /data/qqbot/v2/stop-all.sh
# 诊断:    sh stop-all.sh --match-only <pid> 只打印 match/nomatch，
#          供夹具测试与排障用，不杀任何进程（可配合 V2_PROC /
#          V2_ROOTFS 环境变量指向假 /proc 树）。
# =====================================================================
V2=/data/qqbot/v2
ROOTFS=${V2_ROOTFS:-/data/qqbot/rootfs-v2}
PROC_DIR=${V2_PROC:-/proc}
RUN=$V2/run

match_proc() { # match_proc <pid>: 0 = 是 v2 栈进程（含后端两类令牌形态）
  d="$PROC_DIR/$1"
  [ -d "$d" ] || return 1
  r=$(readlink "$d/root" 2>/dev/null)
  if [ -n "$r" ]; then
    [ "$r" = "$ROOTFS" ]
    return
  fi
  # root 读不到才看令牌 + cwd，两样都对上才认
  c=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
  [ -n "$c" ] || return 1
  a0=${c%% *}
  tok=1
  case "$c" in
    *"/root/qqbot/start-backend.sh"*)
      case "$a0" in *sh*) tok=0 ;; esac ;;
    *"app.py"*)
      case "$a0" in *python3*) tok=0 ;; esac ;;
  esac
  [ $tok -eq 0 ] || return 1
  w=$(readlink "$d/cwd" 2>/dev/null)
  case "$w" in
    "$ROOTFS"|"$ROOTFS"/*) return 0 ;;
  esac
  return 1
}

if [ "$1" = "--match-only" ]; then
  if match_proc "$2"; then echo "match"; else echo "nomatch"; fi
  exit 0
fi

mkdir -p "$V2/logs" 2>/dev/null
exec >>"$V2/logs/stop.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] stop-all 开始"

kill_pidfile() {
  f=$1
  [ -f "$f" ] || return 0
  pid=$(cat "$f" 2>/dev/null)
  rm -f "$f"
  [ -n "$pid" ] || return 0
  PIDS="$PIDS $pid"
  kill -TERM -"$pid" 2>/dev/null
  kill -TERM "$pid" 2>/dev/null
}

PIDS=""
kill_pidfile "$RUN/watcher.pid"
kill_pidfile "$RUN/bot.pid"
kill_pidfile "$RUN/backend.pid"
kill_pidfile "$RUN/napcat.pid"
sleep 2
for pid in $PIDS; do
  kill -KILL -"$pid" 2>/dev/null
  kill -KILL "$pid" 2>/dev/null
done

# 兜底清扫两轮: 第一轮 TERM，第二轮 KILL 残留。
round=1
while [ $round -le 2 ]; do
  sig=TERM
  [ $round -eq 2 ] && sig=KILL
  for d in "$PROC_DIR"/[0-9]*; do
    pid=${d##*/}
    if match_proc "$pid"; then
      kill -$sig "$pid" 2>/dev/null
    fi
  done
  sleep 1
  round=$((round + 1))
done

# 复查
LEFT=""
for d in "$PROC_DIR"/[0-9]*; do
  pid=${d##*/}
  if match_proc "$pid"; then LEFT="$LEFT $pid"; fi
done
[ -n "$LEFT" ] && echo "警告: 仍有 v2 进程未停掉:$LEFT"

# 卸载 v2 挂载（懒卸载，不堵）
for m in dev/pts dev/shm dev sys proc; do
  umount -l "$ROOTFS/$m" 2>/dev/null
done

echo "v2 栈已停止" > /sdcard/qqbot/v2-status.txt 2>/dev/null
echo "[$(date '+%Y-%m-%d %H:%M:%S')] stop-all 完成"
exit 0
