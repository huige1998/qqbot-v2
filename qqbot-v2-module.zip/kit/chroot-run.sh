#!/system/bin/sh
# v2 栈 chroot 执行器（与试验 kit 的 test-chroot-run.sh 同机制，rootfs 不同）
# 用法: chroot-run.sh /root/qqbot/xxx.sh
# 注意: 用 /usr/bin/bash 的绝对路径——usrmerge 布局下 /bin 是软链接，
# 绝对路径两种布局都稳（v0.3 试验的教训）。
ROOTFS=/data/qqbot/rootfs-v2
exec chroot "$ROOTFS" /usr/bin/env -i HOME=/root TERM=xterm \
  PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  /usr/bin/bash --noprofile --norc "$1"
