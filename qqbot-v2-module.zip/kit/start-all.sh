#!/system/bin/sh
# =====================================================================
# QQ机器人 v2 · 启动（NapCat v4 + bot + 本地后端，一栈三件）
#   v2 环境: /data/qqbot/rootfs-v2   （生产 /data/qqbot/rootfs、
#   试验 /data/qqbot/rootfs-test 都不碰）
#   v2 控制: /data/qqbot/v2          （pid、日志都在这里）
# 前置条件: 生产栈必须已停止——同一个 QQ 号不能在两处同时登录。
# 幂等: v2 栈已在跑就直接退出。后端拉起失败只记日志、不挡 NapCat/bot
# （设计 §2.2：后端缺席时机器人仍可先起来，bot v8 之后会自动兜底）。
# 所有输出进 /data/qqbot/v2/logs/start.log。
# 手动运行: sh /data/qqbot/v2/start-all.sh
# =====================================================================
V2=/data/qqbot/v2
ROOTFS=/data/qqbot/rootfs-v2
RUN=$V2/run
LOGS=$V2/logs
SD=/sdcard/qqbot
CHROOT_RUN=$V2/chroot-run.sh
QR_SRC=$ROOTFS/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png

mkdir -p "$RUN" "$LOGS" "$SD/logs" 2>/dev/null
exec >>"$LOGS/start.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] start-all 开始"

# ---- 启动预检（沿用试验 v0.3 的做法）: 解释器与 chroot 本身必须可用 --
# 试验包第一轮就是死在这里且无声无息：先自检，过不了就把原因写进
# 日志并退出，别再白等 240 秒。
if [ -x "$ROOTFS/usr/bin/bash" ]; then
  echo "预检: $ROOTFS/usr/bin/bash 存在且可执行"
else
  echo "预检失败: $ROOTFS/usr/bin/bash 缺失或不可执行，v2 环境不完整"
  exit 1
fi
if [ -e "$ROOTFS/bin/bash" ]; then
  echo "预检: /bin/bash 可解析（usrmerge 布局正常）"
else
  echo "预检警告: /bin/bash 不可解析（/bin 布局异常；chroot 执行器已改用 /usr/bin/bash，不影响本次启动，但建议重装 v2 模块让它修复布局）"
fi
PRE_ERR=$(chroot "$ROOTFS" /usr/bin/true 2>&1)
if [ $? -ne 0 ]; then
  echo "chroot 预检失败: chroot $ROOTFS /usr/bin/true 报错: $PRE_ERR"
  exit 1
fi
echo "预检通过: chroot 可用（/usr/bin/true 正常退出）"

pid_test() { # pid_test <pid>: 活着且进程根目录指向 v2 rootfs 才算 v2 栈进程
  [ -n "$1" ] || return 1
  kill -0 "$1" 2>/dev/null || return 1
  [ "$(readlink "/proc/$1/root" 2>/dev/null)" = "$ROOTFS" ]
}
alive() { # alive <pidfile>
  [ -f "$1" ] || return 1
  pid_test "$(cat "$1" 2>/dev/null)"
}

if alive "$RUN/napcat.pid"; then
  echo "v2 栈已在运行，跳过"
  exit 0
fi
[ -x "$ROOTFS/opt/QQ/qq" ] || { echo "v2 rootfs 不完整（缺 /opt/QQ/qq），先装好 v2 模块"; exit 1; }

# ---- 安全检查: 生产 QQ 还在跑就拒绝启动（同号双登会互相踢下线） ----
for d in /proc/[0-9]*; do
  [ "$(readlink "$d/root" 2>/dev/null)" = "/data/qqbot/rootfs" ] || continue
  case "$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)" in
    *"/opt/QQ/qq"*)
      echo "拒绝启动: 生产栈的 QQ 还在运行。请先在 v2 控制台点「一键从生产切换」，或去生产控制台点「停止机器人」。"
      exit 1 ;;
  esac
done

# ---- 挂载（与生产/试验同款，已挂的跳过；目标是 v2 rootfs） ----------
ismounted() { grep -q " $1 " /proc/mounts 2>/dev/null; }
domount() { # domount <类型/源> <目标> [bind]
  if ismounted "$2"; then return 0; fi
  mkdir -p "$2" 2>/dev/null
  if [ "$3" = "bind" ]; then mount -o bind "$1" "$2" 2>/dev/null
  else mount -t "$1" "$1" "$2" 2>/dev/null; fi
  ismounted "$2" || echo "警告: 挂载 $2 失败"
}
domount proc "$ROOTFS/proc"
domount sysfs "$ROOTFS/sys"
domount /dev "$ROOTFS/dev" bind
domount /dev/pts "$ROOTFS/dev/pts" bind
if ! ismounted "$ROOTFS/dev/shm"; then
  mkdir -p "$ROOTFS/dev/shm"
  mount -t tmpfs -o size=512m tmpfs "$ROOTFS/dev/shm" 2>/dev/null
fi

# ---- 首次启动的一次性环境整理（容器内 prep.sh，带标记，只跑一次） --
# 输出进 prep.log，不吞——环境整理失败也要留线索。
/system/bin/sh "$CHROOT_RUN" /root/qqbot/prep.sh </dev/null >>"$LOGS/prep.log" 2>&1

echo "v2 栈启动中；如需扫码，看 v2 控制台或内部存储/qqbot/qrcode.png" > "$SD/v2-status.txt"

# ---- 起 NapCat v4（启动段已抽到 launch-napcat.sh：拉起 + 记 pid + --
# 等 3001。restart-napcat 只重启 NapCat 时复用同一段，保证两条路径
# 拉起方式完全一致。它的进度输出随本脚本重定向进 start.log；3001
# 没起来它也只是警告，机器人与后端照旧启动——后端缺席时 bot 可先
# 起来，NapCat 缺席时同理不互相拖死。）
/system/bin/sh "$V2/launch-napcat.sh"

# ---- 密钥归位（起后端之前）: 密钥模块刷过后，cookie 暂存在 --------
# /data/qqbot/secrets/cookie.txt；与 v2 环境内副本比对（0600 落盘）：
# 缺失→归位，不同→覆盖，相同→不动也不写日志。设计 §4.1：刷新
# cookie 走「重刷密钥包 + 重启」——重刷后暂存里就是新 cookie，起栈
# 时靠这一步覆盖环境内旧副本，新 cookie 才真正生效。
DST=$ROOTFS/root/workspace/quark-share-watch/cookie.txt
SRC=/data/qqbot/secrets/cookie.txt
if [ -f "$SRC" ]; then
  if [ -f "$DST" ] && cmp -s "$SRC" "$DST" 2>/dev/null; then
    : # 暂存与环境内副本相同，不动
  else
    CKOVERWRITE=0
    [ -f "$DST" ] && CKOVERWRITE=1
    mkdir -p "$(dirname "$DST")" 2>/dev/null
    if cp "$SRC" "$DST" 2>/dev/null; then
      chmod 600 "$DST" 2>/dev/null
      if [ "$CKOVERWRITE" = "1" ]; then
        echo "已用密钥包的新 cookie 覆盖环境内副本（0600）"
      else
        echo "已把暂存的夸克 cookie 归位到 v2 后端（0600）"
      fi
    else
      echo "警告: cookie 归位失败（复制 $SRC 到后端目录失败）"
    fi
  fi
elif [ -f "$DST" ]; then
  echo "后端 cookie 已就位（环境内已有）"
else
  echo "警告: 后端 cookie 缺失——还没刷密钥模块包（qqbot-secrets）。后端能起来，但转存任务会报未登录；刷好密钥包后重启 v2 栈即可。"
fi

# ---- 起本地后端（容器内 start-backend.sh: app.py 看门狗 + 6h 清理） --
setsid /system/bin/sh "$CHROOT_RUN" /root/qqbot/start-backend.sh </dev/null >/dev/null 2>>"$LOGS/launcher.log" &
echo $! > "$RUN/backend.pid"
echo "本地后端看门狗已拉起 pid=$(cat "$RUN/backend.pid")（监听 127.0.0.1:8787）"

# ---- 起机器人看门狗（连 v2 NapCat，程序与生产同一个 bot.js） --------
setsid /system/bin/sh "$CHROOT_RUN" /root/qqbot/start-bot.sh </dev/null >/dev/null 2>&1 &
echo $! > "$RUN/bot.pid"
echo "机器人看门狗已拉起 pid=$(cat "$RUN/bot.pid")"

# ---- 后台小循环: 同步二维码 + 日志到 /sdcard/qqbot -------------------
# 二维码的权威来源是 v4 的缓存目录（app_launcher/napcat/cache，
# 试验实测：v4 的码只落在那里，旧的 root/tmp 查找会漏掉它、只剩
# sdcard 里的陈旧残码）。日志多镜像一份 backend.log。
if ! alive "$RUN/watcher.pid"; then
  setsid /system/bin/sh -c '
    ROOTFS='"$ROOTFS"'; SD='"$SD"'; QRSRC='"$QR_SRC"'; LAST=""
    while true; do
      f=""
      if [ -f "$QRSRC" ]; then
        f=$QRSRC
      else
        f=$(find "$ROOTFS/root" "$ROOTFS/tmp" \
              -type f \( -iname "*qrcode*.png" -o -iname "*qr_code*.png" -o -iname "qr*.png" \) \
              -mmin -30 2>/dev/null | head -n 1)
      fi
      if [ -n "$f" ]; then
        sig=$(wc -c < "$f" 2>/dev/null)
        if [ "$sig" != "$LAST" ]; then
          cp "$f" "$SD/qrcode.png" 2>/dev/null && LAST=$sig
        fi
      fi
      cp "$ROOTFS/root/qqbot/napcat.log" "$SD/logs/napcat.log" 2>/dev/null
      cp "$ROOTFS/root/qqbot/bot.log" "$SD/logs/bot.log" 2>/dev/null
      cp "$ROOTFS/root/qqbot/backend.log" "$SD/logs/backend.log" 2>/dev/null
      sleep 5
    done
  ' </dev/null >/dev/null 2>&1 &
  echo $! > "$RUN/watcher.pid"
  echo "二维码/日志同步循环已拉起 pid=$(cat "$RUN/watcher.pid")"
fi

echo "v2 栈已上线（NapCat + 后端 + 机器人）" > "$SD/v2-status.txt"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] start-all 完成"
exit 0
