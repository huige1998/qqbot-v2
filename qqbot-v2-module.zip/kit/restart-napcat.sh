#!/system/bin/sh
# =====================================================================
# QQ机器人 v2 · 只重启 NapCat（QQ 本体），不动后端与机器人
# 用途: 二维码过期后，NapCat v4 在真机上并不会可靠地自己换新码——
# 重启 NapCat 是拿新码的可靠办法。机器人与 NapCat 是 WebSocket
# 客户端关系：NapCat 回来后机器人自行重连（bot.js 的重连循环），
# 后端（app.py）与机器人全程不重启、不丢任务状态。
# 清扫规则（与 stop-all.sh 同源、但更窄，只认 QQ 侧进程）:
#   必要条件: /proc/<pid>/root == /data/qqbot/rootfs-v2。生产栈的
#     root 是 rootfs、试验是 rootfs-test，原理上不可能命中；
#     root 读不到直接不认——QQ 进程树的 root 都读得到，不需要
#     「令牌 + cwd」回退，宁可漏杀也不能错杀。
#   且 cmdline 命中 QQ 侧令牌之一: /opt/QQ/qq（QQ 主进程及其
#     zygote/renderer 子进程都带这个路径）、start-napcat.sh
#     （容器内启动器）、xvfb / Xvfb（QQ 图形界面用的虚拟显示）、
#     app_launcher（NapCat 注入相关路径）。
#   且 cmdline 不含排除令牌（先判排除）: app.py、start-backend
#     （本地后端本体与看门狗）、bot.js、start-bot（机器人本体与
#     看门狗）——这两件即使其它条件都像也绝不杀。
# 流程: pid 文件整组 TERM → 清扫命中进程 TERM → 等最多 10 秒 →
# 残留 KILL → 删旧二维码（缓存 + sdcard 镜像，免得新码出来前
# 控制台闪旧码）→ launch-napcat.sh 重新拉起。
# 若 v2 栈根本没在跑（rootfs-v2 里一个进程都没有），拒绝单独拉
# NapCat（挂载/prep 都不在，拉也拉不起来），提示先点「启动」。
# 手动运行: sh /data/qqbot/v2/restart-napcat.sh（输出进 restart.log）
# 诊断:    sh restart-napcat.sh --match-only <pid> 只打印
#          match/nomatch，不杀任何进程（可配合 V2_PROC /
#          V2_ROOTFS 环境变量指向假 /proc 树，供夹具测试）。
# =====================================================================
V2=/data/qqbot/v2
ROOTFS=${V2_ROOTFS:-/data/qqbot/rootfs-v2}
PROC_DIR=${V2_PROC:-/proc}
RUN=$V2/run
QRCACHE=$ROOTFS/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png
QRMIRROR=/sdcard/qqbot/qrcode.png

match_napcat() { # match_napcat <pid>: 0 = 是 v2 的 QQ/NapCat 进程
  d="$PROC_DIR/$1"
  [ -d "$d" ] || return 1
  r=$(readlink "$d/root" 2>/dev/null)
  [ "$r" = "$ROOTFS" ] || return 1
  c=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
  [ -n "$c" ] || return 1
  case "$c" in
    *app.py*|*start-backend*|*bot.js*|*start-bot*) return 1 ;; # 后端/机器人绝不杀（先判排除）
  esac
  case "$c" in
    *"/opt/QQ/qq"*|*"start-napcat.sh"*|*xvfb*|*Xvfb*|*"app_launcher"*) return 0 ;;
  esac
  return 1
}

any_v2_proc() { # v2 rootfs 里还有没有任何进程（判断栈是否活着）
  for d in "$PROC_DIR"/[0-9]*; do
    [ "$(readlink "$d/root" 2>/dev/null)" = "$ROOTFS" ] && return 0
  done
  return 1
}

if [ "$1" = "--match-only" ]; then
  if match_napcat "$2"; then echo "match"; else echo "nomatch"; fi
  exit 0
fi

mkdir -p "$V2/logs" 2>/dev/null
exec >>"$V2/logs/restart.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] restart-napcat 开始（只重启 NapCat，后端与机器人不动）"

if ! any_v2_proc; then
  echo "v2 栈没在运行（rootfs-v2 里没有进程），拒绝单独拉 NapCat：请先在控制台点「启动」"
  exit 1
fi

# 先按 pid 文件整组 TERM（拉起 NapCat 的那棵进程树）
if [ -f "$RUN/napcat.pid" ]; then
  NP=$(cat "$RUN/napcat.pid" 2>/dev/null)
  rm -f "$RUN/napcat.pid"
  if [ -n "$NP" ]; then
    kill -TERM -"$NP" 2>/dev/null
    kill -TERM "$NP" 2>/dev/null
  fi
fi

# 清扫命中的 QQ/NapCat 进程: TERM → 等最多 10 秒 → 残留 KILL
for d in "$PROC_DIR"/[0-9]*; do
  pid=${d##*/}
  if match_napcat "$pid"; then kill -TERM "$pid" 2>/dev/null; fi
done
i=0
while [ $i -lt 10 ]; do
  LEFT=0
  for d in "$PROC_DIR"/[0-9]*; do
    pid=${d##*/}
    if match_napcat "$pid"; then LEFT=1; break; fi
  done
  [ $LEFT -eq 0 ] && break
  sleep 1
  i=$((i + 1))
done
for d in "$PROC_DIR"/[0-9]*; do
  pid=${d##*/}
  if match_napcat "$pid"; then kill -KILL "$pid" 2>/dev/null; fi
done
sleep 1
echo "旧 NapCat 已清扫（等待 $((i)) 秒）"

# 删旧二维码：新码出来之前控制台宁可显示「暂无」，也不闪旧码
rm -f "$QRCACHE" "$QRMIRROR" 2>/dev/null

# 重新拉起（与整栈启动共用同一段）
/system/bin/sh "$V2/launch-napcat.sh"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] restart-napcat 完成（新二维码将在 NapCat 出码后出现在控制台）"
exit 0
