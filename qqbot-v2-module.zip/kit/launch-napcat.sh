#!/system/bin/sh
# =====================================================================
# QQ机器人 v2 · NapCat v4 启动段（从 start-all.sh 抽出共用）
# start-all（整栈启动）与 restart-napcat（只重启 NapCat 拿新码）都走
# 这里，保证两条路径拉起 NapCat 的方式完全一致。
# 只做三件事：拉起容器内 start-napcat.sh、记 napcat.pid、等 3001
# 监听（最多 240 秒）。前置工作（挂载、prep、登录态、与生产的互斥
# 检查）由调用方负责——重启 NapCat 时栈还在跑，那些都现成。
# 输出写 stdout，由调用方重定向（start-all→start.log、
# restart-napcat→restart.log）；容器内启动器的 stderr 仍进
# launcher.log（bash 没跑起来时的错误在这里留底）。
# =====================================================================
V2=/data/qqbot/v2
ROOTFS=/data/qqbot/rootfs-v2
RUN=$V2/run
LOGS=$V2/logs
CHROOT_RUN=$V2/chroot-run.sh

mkdir -p "$RUN" "$LOGS" 2>/dev/null

# 容器内启动器: xvfb-run 拉起 QQ 图形界面（NapCat 注入其中）
setsid /system/bin/sh "$CHROOT_RUN" /root/qqbot/start-napcat.sh </dev/null >/dev/null 2>>"$LOGS/launcher.log" &
echo $! > "$RUN/napcat.pid"
echo "NapCat 已拉起 pid=$(cat "$RUN/napcat.pid")，等端口 3001…"

# 等 WS 端口 3001 (0x0BB9) 进入 LISTEN，最多 240 秒
i=0
while [ $i -lt 48 ]; do
  if cat /proc/net/tcp /proc/net/tcp6 2>/dev/null | awk '$2 ~ /:0BB9$/ && $4 == "0A" {f=1} END {exit !f}'; then
    echo "端口 3001 已监听"
    break
  fi
  sleep 5
  i=$((i + 1))
done
[ $i -ge 48 ] && echo "警告: 240 秒内 3001 没起来，看 NapCat 日志排查"
exit 0
