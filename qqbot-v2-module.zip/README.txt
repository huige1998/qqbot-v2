QQ机器人 v2（NapCat v4 + 本地后端）正式模块 v2.0.0。
完整安装顺序、切换与回滚说明见同包的 README-V2.md（安装后也会复制一份到手机的 /data/qqbot/v2/README-V2.md）。
