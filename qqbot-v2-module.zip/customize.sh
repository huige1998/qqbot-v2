#!/system/bin/sh
# QQ机器人 v2（NapCat v4 + 本地后端）—— 安装脚本（Magisk 安装器环境）
# 与生产模块 qqbot-magisk、试验模块 qqbot_v4test 完全并存：本模块只写
# /data/qqbot/rootfs-v2 与 /data/qqbot/v2，生产（rootfs）与试验
# （rootfs-test）全程只读、绝不删改——回滚就是停 v2、用回生产。
# 流程（与试验模块同构，另加正式版的回滚安全与密钥归位）:
#   1. v2 环境已装好（关键路径在）→ 跳过解压，只刷新主机脚本与说明；
#   2. rootfs-v2 在但关键路径缺失 = 上次解压失败的半成品 → 先改名
#      rootfs-v2.bak-<时间戳> 保留（不删），再重新解压；
#   3. 首次安装才需要 napcat-v2-pack.tar.gz：/sdcard 或 /sdcard/Download
#      里找，/data 剩余 ≥3.5GB 才解压；解压失败同样把半成品改名保留
#      并中止，不留半装状态；
#   4. usrmerge /bin、/sbin 布局检查修复（幂等，沿用试验 v0.3 的逻辑；
#      v2 树在 VM 上已是修复后的布局，这一步是防解压工具捣乱的保险）；
#   5. 把生产 /data/qqbot/rootfs/root/.config/QQ 只读复制一份到 v2 环境
#      作登录态种子（v2 侧已有时不覆盖；v4 试验已实证这份登录态能在
#      QQ 3.2.34 上快速登录）；
#   6. 密钥归位：/data/qqbot/secrets/cookie.txt 若在（密钥模块先刷过），
#      把 cookie 归位到 v2 后端目录（0600）：环境内缺失→补入，与暂存
#      不同→覆盖（刷新 cookie 就靠重刷密钥包后这一步换新），相同→
#      不动；起栈时 start-all 还会再检查一次，没刷密钥包也能先装
#      本模块。
#   7. （v2.1.0 新增）机器人补丁：模块自带的 files/bot.js（bot v8，
#      本地优先 + 日志回传命令）与 v2 环境内的 bot.js 不同时覆盖
#      它，旧版先备份为 bot.js.bak-v7（已有备份不覆盖）；主机脚本
#      （kit）一并刷新（含新的 launch-napcat.sh / restart-napcat.sh）。
#   8. （v2.1.0 新增）控制台页面刷新：把新版 webroot 刷进正在生效
#      的模块目录 /data/adb/modules/qqbot_v2/webroot，装完不用重启
#      就能用上新控制台（首次安装没有旧目录，跳过并说明）。
# 本模块没有 service.sh：装完不自动运行任何东西，v2 栈在 v2 控制台
# 里点按钮启动（或手动跑 /data/qqbot/v2/start-all.sh）。
# 云更新（v2.1.0 起）：module.prop 已写 updateJson（仓库
# huige1998/qqbot-v2）；但手机上现装的 v2.0.0 没有这个地址，本版
# 仍需手动安装一次，之后的新版在 Magisk 里点「更新」即可。

DATA=/data/qqbot
V2ROOT=$DATA/rootfs-v2

ui_print "********************************"
ui_print " QQ机器人 v2（NapCat v4 + 本地后端）v2.1.0"
ui_print " 装到独立 v2 目录，与生产/试验并存，互不动"
ui_print " 本版：bot v8 本地优先+日志回传、刷新二维码、"
ui_print " 控制台防卡死、接入 Magisk 云更新"
ui_print "********************************"

# 1) 架构检查：只支持 arm64（与生产/试验模块一致）
if [ "$ARCH" != "arm64" ]; then
  abort "! 本模块只支持 arm64 设备（当前: ${ARCH:-未知}），已取消安装"
fi
ui_print "- 架构检查通过: arm64"

# 2) 生产环境必须在（登录态要从它复制；没有生产就先别装 v2）
if [ ! -d "$DATA/rootfs" ]; then
  abort "! 没找到生产环境 /data/qqbot/rootfs，生产模块没装好？先装好生产模块再来装 v2"
fi

mkdir -p "$DATA" 2>/dev/null
BB=""
[ -x /data/adb/magisk/busybox ] && BB=/data/adb/magisk/busybox
TS=$(date +%Y%m%d-%H%M%S)

# 3) v2 环境是否已装好（关键路径判定）：装好了就跳过解压，只刷新。
NEED_EXTRACT=1
if [ -x "$V2ROOT/opt/QQ/qq" ]; then
  NEED_EXTRACT=0
  ui_print "- v2 环境已安装，跳过解压（只刷新脚本与说明）"
fi

if [ "$NEED_EXTRACT" = "1" ]; then
  # 3a) 回滚安全：半成品 rootfs-v2（关键路径不在）先改名保留，不删。
  if [ -e "$V2ROOT" ]; then
    mv "$V2ROOT" "$V2ROOT.bak-$TS" 2>/dev/null \
      && ui_print "- 发现上次未装完的 v2 环境，已改名保留为 rootfs-v2.bak-$TS（确认新版没问题后可手动删）" \
      || abort "! rootfs-v2 存在但不完整，且改名保留失败，已取消安装（先手动处理 /data/qqbot/rootfs-v2 再重试）"
  fi

  # 4) 找正式大包：先 /sdcard 根目录，再 /sdcard/Download
  SRC=""
  for CAND in /sdcard/napcat-v2-pack.tar.gz /sdcard/Download/napcat-v2-pack.tar.gz; do
    if [ -f "$CAND" ]; then SRC="$CAND"; break; fi
  done
  if [ -z "$SRC" ]; then
    abort "! 没找到 napcat-v2-pack.tar.gz。先把这个大包放到内部存储根目录（/sdcard/）或 Download 里，再重新安装本模块"
  fi
  ui_print "- 找到 v2 正式包: $SRC"

  # 5) 空间检查：解压后约 2.1GB，要求 /data 剩余 ≥3.5GB（留增长余量；
  #    若刚改名保留了 .bak 半成品，它也占着空间，不够时提示里会说明）
  FREE_KB=$(df -k /data 2>/dev/null | tail -n 1 | awk '{print $4}')
  case "$FREE_KB" in
    ''|*[!0-9]*) ui_print "- 警告: 读不到 /data 剩余空间，跳过空间检查";;
    *)
      FREE_GB=$((FREE_KB / 1048576))
      ui_print "- /data 剩余空间: ${FREE_GB}GB"
      if [ "$FREE_KB" -lt 3670016 ]; then
        abort "! /data 只剩 ${FREE_GB}GB，不足 3.5GB。先清理空间再装（rootfs-v2.bak-* 的旧备份确认没用可以删），否则解压会半途失败"
      fi
      ;;
  esac

  # 6) 解压（顶层只有 rootfs-v2/ 一棵树，落点 /data/qqbot/）
  ui_print "- 正在解压 v2 正式包（约 2.1GB，需要几分钟，别切后台杀进程）…"
  if [ -n "$BB" ]; then
    "$BB" tar -xzf "$SRC" -C "$DATA"
  else
    tar -xzf "$SRC" -C "$DATA"
  fi
  if [ $? -ne 0 ] || [ ! -x "$V2ROOT/opt/QQ/qq" ]; then
    if [ -e "$V2ROOT" ]; then
      mv "$V2ROOT" "$V2ROOT.bak-$TS" 2>/dev/null
      ui_print "! 解压不完整，半成品已改名保留为 rootfs-v2.bak-$TS"
    fi
    abort "! 解压失败（包损坏？存储空间不够？）。处理后重新安装本模块即可"
  fi
  ui_print "- 解压完成"
fi

# 7) 布局修复（幂等，与试验模块 v0.3 同逻辑）：usrmerge 要求 /bin、
#    /sbin 是指向 usr/bin、usr/sbin 的软链接；若被解压工具冲成真实
#    目录（/bin/bash 缺失），chroot 里连解释器都找不到，整栈起不来。
fix_bindir() { # fix_bindir <bin|sbin>
  D="$V2ROOT/$1"
  U="$V2ROOT/usr/$1"
  if [ -L "$D" ]; then
    ui_print "- /$1 布局正常（已是软链接），不用修"
    return 0
  fi
  if [ -d "$D" ]; then
    for F in "$D"/*; do
      [ -e "$F" ] || [ -L "$F" ] || continue
      B=$(basename "$F")
      if [ ! -e "$U/$B" ] && [ ! -L "$U/$B" ]; then
        if cp -a "$F" "$U/$B"; then
          ui_print "- 已把 /$1 独有的 $B 补进 /usr/$1"
        fi
      fi
    done
    rm -rf "$D"
    ln -s "usr/$1" "$D"
    ui_print "- 已修复 /$1：真实目录改为指向 usr/$1 的软链接"
  else
    ln -s "usr/$1" "$D" 2>/dev/null
    ui_print "- /$1 不存在，已补建指向 usr/$1 的软链接"
  fi
}
fix_bindir bin
fix_bindir sbin
if [ ! -e "$V2ROOT/bin/bash" ]; then
  abort "! 布局修复后仍找不到 /bin/bash，v2 环境可能不完整。请把这行报错截图发给我"
fi
ui_print "- 布局检查通过：/bin/bash 可用"

# 8) 校验关键路径（QQ 本体 + 后端树 + 容器内启动器都在才算装好）
if [ ! -x "$V2ROOT/opt/QQ/qq" ]; then
  abort "! 没找到 v2 的 QQ 程序（/data/qqbot/rootfs-v2/opt/QQ/qq），包可能不完整"
fi
if [ ! -f "$V2ROOT/root/workspace/pan-search-app/app.py" ]; then
  abort "! 没找到 v2 的本地后端（rootfs-v2/root/workspace/pan-search-app/app.py），包可能不完整"
fi
if [ ! -f "$V2ROOT/root/qqbot/start-backend.sh" ]; then
  abort "! 没找到后端启动器（rootfs-v2/root/qqbot/start-backend.sh），包可能不完整"
fi

# 9) 安装/刷新主机脚本到 /data/qqbot/v2（控制台按钮调用的就是这几个；
#    v2.1.0 起 kit 多了 launch-napcat.sh / restart-napcat.sh，一并刷新）
mkdir -p "$DATA/v2/run" "$DATA/v2/logs" 2>/dev/null
if [ -d "$MODPATH/kit" ]; then
  for S in start-all.sh stop-all.sh chroot-run.sh launch-napcat.sh restart-napcat.sh; do
    if [ -f "$MODPATH/kit/$S" ]; then
      cp -f "$MODPATH/kit/$S" "$DATA/v2/$S" 2>/dev/null
    fi
  done
  ui_print "- v2 主机脚本已刷新到最新"
fi
chmod 755 "$DATA"/v2/*.sh 2>/dev/null
if [ ! -f "$DATA/v2/start-all.sh" ]; then
  abort "! 主机脚本安装失败（/data/qqbot/v2/start-all.sh 不存在），已取消"
fi

# 10) 复制生产登录态到 v2 环境（只读生产，只写 v2；v2 侧已有则不覆盖）
if [ -d "$DATA/rootfs/root/.config/QQ" ]; then
  if [ -d "$V2ROOT/root/.config/QQ" ]; then
    ui_print "- v2 环境已有登录态，保留它（不覆盖）"
  else
    mkdir -p "$V2ROOT/root/.config" 2>/dev/null
    if cp -a "$DATA/rootfs/root/.config/QQ" "$V2ROOT/root/.config/QQ"; then
      ui_print "- 已把生产登录态复制到 v2 环境：首启先试快速登录，失败会自动出二维码"
    else
      ui_print "- 警告: 复制登录态失败，v2 首启将走扫码登录（不影响使用）"
    fi
  fi
else
  ui_print "- 生产环境没有现成登录态，v2 首启将走扫码登录"
fi

# 11) 密钥归位（设计 §4.1 的暂存交接）：密钥模块若先刷过，cookie 在
#     /data/qqbot/secrets/cookie.txt 暂存；这里与 v2 后端目录内的副本
#     比对（0600 落盘）：缺失→归位，不同→覆盖（§4.1 刷新流程就是
#     「重刷密钥包 + 重启」，覆盖必须发生新 cookie 才生效），相同→
#     不动也不刷屏。起栈时 start-all 还会再检查一次，所以顺序反过来
#     （先装 v2、后刷密钥包）也没关系。
CKSRC="$DATA/secrets/cookie.txt"
CKDST="$V2ROOT/root/workspace/quark-share-watch/cookie.txt"
if [ -f "$CKSRC" ]; then
  if [ -f "$CKDST" ] && cmp -s "$CKSRC" "$CKDST" 2>/dev/null; then
    : # 暂存与环境内副本相同，不动
  else
    CKOVERWRITE=0
    [ -f "$CKDST" ] && CKOVERWRITE=1
    mkdir -p "$(dirname "$CKDST")" 2>/dev/null
    if cp "$CKSRC" "$CKDST" 2>/dev/null; then
      chmod 600 "$CKDST" 2>/dev/null
      if [ "$CKOVERWRITE" = "1" ]; then
        ui_print "- 已用密钥包的新 cookie 覆盖环境内副本（0600）"
      else
        ui_print "- 已把密钥暂存里的夸克 cookie 归位到 v2 后端（0600）"
      fi
    else
      ui_print "- 警告: cookie 归位失败，起栈后看 v2 控制台的后端状态"
    fi
  fi
elif [ -f "$CKDST" ]; then
  ui_print "- 后端 cookie 已就位（v2 环境内已有）"
else
  ui_print "- 提示: 还没刷密钥模块包（qqbot-secrets），后端暂时没有夸克 cookie——先这样装完，刷好密钥包后在 v2 控制台点「启动」即可（start-all 会自动归位）"
fi

# 12) 机器人补丁（v2.1.0 新增）：模块自带的 files/bot.js 是 bot v8
#     （本地优先 + 群里主人发「日志」回传日志）。这一步放在所有安装
#     路径都会走到的地方——已装好 v2 的机器重刷本模块走的是「跳过
#     解压」路径，靠这一步才拿到新机器人。规则：目标缺失→直接补入
#     （自愈）；目标已是同一份→跳过；不同→旧版先备份为
#     bot.js.bak-v7（只备第一份，已有备份绝不覆盖），再覆盖。
BOTDST="$V2ROOT/root/qqbot/bot.js"
BOTSRC="$MODPATH/files/bot.js"
if [ -f "$BOTSRC" ]; then
  if [ -f "$BOTDST" ] && cmp -s "$BOTSRC" "$BOTDST" 2>/dev/null; then
    ui_print "- 机器人已是 v8，跳过"
  else
    if [ -f "$BOTDST" ] && [ ! -e "$BOTDST.bak-v7" ]; then
      cp -a "$BOTDST" "$BOTDST.bak-v7" 2>/dev/null
    fi
    mkdir -p "$(dirname "$BOTDST")" 2>/dev/null
    if cp -f "$BOTSRC" "$BOTDST" 2>/dev/null; then
      ui_print "- 已更新机器人到 v8（本地优先）（旧版备份在 bot.js.bak-v7）"
    else
      ui_print "- 警告: 机器人更新失败（bot.js 复制不成功），排障时请说明"
    fi
  fi
else
  ui_print "- 警告: 模块内没找到 files/bot.js，跳过机器人更新"
fi

# 13) 控制台页面刷新（v2.1.0 新增）：Magisk 安装时新版 webroot 进的是
#     暂存目录，要等重启才换到生效目录；这里顺手把新版页面刷进正在
#     生效的 /data/adb/modules/qqbot_v2/webroot，装完重新打开控制台
#     就是新版（不用重启手机）。首次安装没有旧目录（本模块自己就是
#     新装的），跳过并说明。
LIVEWEB="/data/adb/modules/qqbot_v2/webroot"
if [ -f "$MODPATH/webroot/index.html" ] && [ -d "$LIVEWEB" ]; then
  if cmp -s "$MODPATH/webroot/index.html" "$LIVEWEB/index.html" 2>/dev/null; then
    ui_print "- 控制台页面已是最新，跳过"
  elif cp -f "$MODPATH/webroot/index.html" "$LIVEWEB/index.html" 2>/dev/null; then
    ui_print "- 控制台页面已刷新到新版（重新打开 v2 控制台即可，不用重启）"
  else
    ui_print "- 警告: 控制台页面刷新失败，重启手机后也会生效（模块本体已更新）"
  fi
elif [ -f "$MODPATH/webroot/index.html" ]; then
  ui_print "- 首次安装：控制台页面随模块就位（没有旧页面需要刷新）"
else
  ui_print "- 警告: 模块内没找到 webroot/index.html，跳过页面刷新"
fi

# 14) 操作说明覆盖到手机上那份
if [ -f "$MODPATH/README-V2.md" ]; then
  cp -f "$MODPATH/README-V2.md" "$DATA/v2/README-V2.md" 2>/dev/null
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644

ui_print "********************************"
ui_print " 安装完成"
ui_print " - v2 环境: /data/qqbot/rootfs-v2"
ui_print " - v2 脚本: /data/qqbot/v2/"
ui_print " - 生产（rootfs）与试验（rootfs-test）没动过"
ui_print " - 本模块不会自启任何东西"
ui_print " 接下来:"
ui_print " 1. 若还没刷密钥模块包，先刷 qqbot-secrets"
ui_print " 2. 在 Magisk 模块列表打开本模块的 WebUI"
ui_print "    （QQ机器人 v2 控制台），点「一键从生产切换」"
ui_print " 完整步骤看: /data/qqbot/v2/README-V2.md"
ui_print "********************************"
